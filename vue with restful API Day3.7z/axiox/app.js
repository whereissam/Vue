let List = {
    template:`
    <div>
    <p>
        <input type="text" placeholder="write something..." v-model.trim='message'>
        <button @click='Create'>Create</button>
    </p>
    <ol>
        <li v-for='(city,index) in citiesname' :key='city.id'>
            {{city.firstName}}
            <button @click='Update(index)'>UPDATE</button>
            <button @click='Delete(index)'>DELETE</button>
        </li>
    </ol>
    </div>`,
    data(){
        return{
            message: 'Hello Vue!',
            // citiesname:[]
        }
    },
    computed:{
        citiesname:{
            get(){return this.$store.state.citiesname},
            set(value){this.$store.commit('setContents',value)}
        }
    },
    methods:{
        Create(){
            if(!this.message) return false
           axios.post('http://localhost:3000/citiesname',{
               firstName: this.message
           }).then((res) => {
               this.message = ''
            //    this.citiesname.push(res.data) //directly push to mutation will have error
                this.$store.commit('addContent',res.data)
           })
        },
        Delete(index){ //Do not use Index
            let target = this.citiesname[index]
            // console.log(target.id)
            // axios.delete(`http://localhost:3000/citiesname/${target.id}`)
            // .then((res)=>{ //取完api 直接splice會報錯，走正規路徑
            //     this.citiesname.splice(index,1)
            // })
            this.$store.dispatch('CONTENT_DELETE',{target})
        }, 
        Update(index){
            // console.log(this) //印出所有功能
            let target = this.citiesname[index]
            // console.log(target)
            // this.$router.push({path:'/update/' + target.id}) //有返回
            this.$router.push({name:'/update/', params:{id: target.id} }) //有返回

            // this.$router.replace({path: '/update/' + target.id})
        },
    },
    mounted () {
        axios
            .get('http://localhost:3000/citiesname')
            .then((res)=>{this.citiesname = res.data})
    }
}

let Edit = {
    template:`
    <div>
    <p>
        <input type='text' v-model.trim='message'>
        <button>Edit</button>
    </p>
    </div>`,
    data(){
        return{
            message:''
        }
    },
    // computed:{
    //     citiesname(){
    //         return this.$store.state.citiesname.find((item)=>{
    //             return item.id = this.$route.params.id
    //             // console.log(item)
    //         })
    //     }
    // },
    mounted(){
        this.message = this.$store.state.citiesname.filter((item) =>{
            return item.id == this.$route.params.id
        })[0].firstName
    //    if(!this.citiesname) return this.$router.replace({path:'/'})
    //    this.message = this.citiesname.citiesname
    }
}

let store = new Vuex.Store({ //vue -> actions -> mutations -> state
    strict: true,
    state: {
        citiesname:[]
    },
    mutations:{
        setContents(state,data){
            state.citiesname = data
        },
        addContent(state, data){
            state.citiesname.push(data)
        },
        deleteContent(state,data){
            state.citiesname.splice(data,1)
        }
    },
    actions:{
        CONTENTS_READ:(context)=>{
            // console.log(context)
            return axios.get('http://localhost:3000/citiesname')
            .then((res)=>{
                context.commit('setContents',res.data)
            })
        },
        CONTENT_DELETE:(context,{target}) =>{
            // console.log('DELETE')
            let index = context.state.citiesname.indexOf(target)
            if( index == -1 ) return false
            return axios.delete('http://localhost:3000/citiesname/' + target.id)
                    .then((res) => {context.commit('deleteContent',)})
        },
    }
})
// 1. router 指定component 
// 2.component指定template
// 3. 指定component's template 顯示位置
let router = new VueRouter({
    routes:[
        {
            path:'/',
            name: 'list', //辨識路由名稱
            component: List //模組習慣大寫開頭
        },
        {
            path:'/update/:id',
            name:'update',
            component: Edit
        },
        {
            path:'*',
            redirect: '/'
        }
    ]
})

new Vue({
    el: '#app',
    router,
    store,
  })