new Vue({
    el: '#app',
    data(){
        return{
            message: 'Hello Vue!',
            updates:'',
            citiesname:[]
        }
    },
    methods:{
        create(){
            if(!this.message) return false
           axios.post('http://localhost:3000/citiesname',{
               firstName: this.message
           }).then((res) => {
               this.message = ''
               this.citiesname.push(res.data) 
           })
        },
        Update(index){
            this.citiesname.index
        },
        Delete(index){ //Do not use Index
            let target = this.citiesname[index]
            axios.delete(`http://localhost:3000/citiesname/${target.id}`)
            .then((res)=>{
                this.citiesname.splice(index,1)
            })
        }
    },
    mounted () {
        axios
            .get('http://localhost:3000/citiesname')
            .then((res)=>{this.citiesname = res.data})
    }
    
  })