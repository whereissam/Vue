let List = {
    template:`
    <div>
    <p>
        <input type="text" placeholder="write something..." v-model.trim='message'>
        <button @click='create'>Create</button>
    </p>
    <ol>
        <li v-for='(city,index) in citiesname' :key='city.id'>
            {{city.firstName}}
            <button @click='Update'>UPDATE</button>
            <button @click='Delete(index)'>DELETE</button>
        </li>
    </ol>
    </div>`,
    data(){
        return{
            message: 'Hello Vue!',
            updates:'',
            citiesname:[]
        }
    },
    methods:{
        create(){
            if(!this.message) return false
           axios.post('http://localhost:3000/citiesname',{
               firstName: this.message
           }).then((res) => {
               this.message = ''
               this.citiesname.push(res.data) 
           })
        },
        Update(index){
            this.citiesname.index
        },
        Delete(index){ //Do not use Index
            let target = this.citiesname[index]
            axios.delete(`http://localhost:3000/citiesname/${target.id}`)
            .then((res)=>{
                this.citiesname.splice(index,1)
            })
        }
    },
    mounted () {
        axios
            .get('http://localhost:3000/citiesname')
            .then((res)=>{this.citiesname = res.data})
    }
}
let Edit = {
    template:`
    <div>
    <input type='text'>
    <button>Edit</button>
    </div>`,
  
}
// 1. router 指定component 
// 2.component指定template
// 3. 指定component's template 顯示位置
let router = new VueRouter({
    routes:[
        {
            path:'/',
            name: 'list', //辨識路由名稱
            component: List //模組習慣大寫開頭
        },
        {
            path:'/update/:id',
            name:'update',
            component: Edit
        },
        {
            path:'*',
            redirect: '/'
        }
    ]
})

new Vue({
    el: '#app',
   
    router:router,
    
    
  })